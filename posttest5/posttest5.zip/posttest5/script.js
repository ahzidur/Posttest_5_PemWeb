// alert("Selamat Datang di Website Toko Elektronik")

function darkmode() {
    var element = document.body;
    element.classList.toggle("dark-mode-body");
    var content = document.getElementById("darkMode");
}

const judul = document.getElementById('judul');
judul.style.color = 'white';
judul.style.fontStyle = 'italic'




